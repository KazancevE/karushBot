module.exports = {
    token: '6600094203:AAEWGt9GWvkAkgAKIkEP3A5xP3vQzNqrON0',
    urlWeb: 'https://arm-dom.tomsk.ru/'
}